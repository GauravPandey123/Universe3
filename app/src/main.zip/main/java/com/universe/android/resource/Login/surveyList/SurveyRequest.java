package com.universe.android.resource.Login.surveyList;

import com.universe.android.web.BaseRequest;

/**
 * Created by gaurav.pandey on 04-03-2018.
 */

public class SurveyRequest extends BaseRequest {

    @Override
    public boolean isValid(String Scenario) {
        return true;
    }
}
