package com.universe.android.utility;

/**
 * Created by gaurav.pandey on 23-01-2018.
 */

public class Constants {
    public static final boolean ANALYTICS_ENABLE = false;
    public static final String BASE_URL = "http://13.127.101.233:3005";

    public static final String AUTH_KEY = "jkjjkxjkjskjxkjksjkxjskjkxjkjskjxksjkkjkxsj";
}

