package com.universe.android.resource.Login.questions;

import com.universe.android.web.BaseRequest;

import java.util.Date;

/**
 * Created by gaurav.pandey on 06-02-2018.
 */

public class QuestionsRequest extends BaseRequest {

    @Override
    public boolean isValid(String Scenario) {
        return true;
    }
}
