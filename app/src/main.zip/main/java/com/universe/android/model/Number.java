package com.universe.android.model;

/**
 * Created by Gunaseelan on 31-12-2015.
 */
public class Number {
    private String ONEs;
    private String textONEs;
    private boolean isSelected;

    public String getTextONEs() {
        return textONEs;
    }

    public void setTextONEs(String textONEs) {
        this.textONEs = textONEs;
    }

    public String getONEs() {
        return ONEs;
    }

    public void setONEs(String ONEs) {
        this.ONEs = ONEs;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
