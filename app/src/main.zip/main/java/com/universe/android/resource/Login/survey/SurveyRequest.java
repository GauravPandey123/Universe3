package com.universe.android.resource.Login.survey;

import com.universe.android.web.BaseRequest;

/**
 * Created by gaurav.pandey on 06-02-2018.
 */

public class SurveyRequest extends BaseRequest {


    @Override
    public boolean isValid(String Scenario) {
        return true;
    }
}
