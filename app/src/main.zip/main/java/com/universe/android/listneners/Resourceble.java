package com.universe.android.listneners;

/**
 * Created by Konstantin on 12.01.2015.
 */
public interface Resourceble {
    public int getImageRes();

    public String getName();

    public String getTitle();
}
