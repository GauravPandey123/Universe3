package com.universe.android.resource.Login.NewRetailor.StateAndCrop;

import com.universe.android.web.BaseRequest;

/**
 * Created by gaurav.pandey on 03-03-2018.
 */

public class StateAndCropRequest extends BaseRequest {
    @Override
    public boolean isValid(String Scenario) {
        return true;
    }
}
