package com.universe.android.listneners;

/**
 * Created by ankush.bansal on 28-02-2018.
 */



public interface IUpdateTask {
    /**
     * Update fragment.
     */
    void updateFragment(int pos,String catgeoryId,String data,String update);
}